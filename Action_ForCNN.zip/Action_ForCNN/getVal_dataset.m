% obtain the Validation set
clear all;
%% Step 1: get the validation data (divide the orignal traning set into 75% training and 25% validation )
% create these folder under the folder 'val'
if ~exist('val\Phoning','dir')
   mkdir('val\Phoning');
end
if ~exist('val\PlayingGuitar','dir')
   mkdir('val\PlayingGuitar');
end
if ~exist('val\RidingBike','dir')
   mkdir('val\RidingBike');
end
if ~exist('val\RidingHorse','dir')
   mkdir('val\RidingHorse');
end
if ~exist('val\Running','dir')
   mkdir('val\Running');
end
if ~exist('val\Shooting','dir')
   mkdir('val\Shooting');
end

% copy the 25% tranining set to the validation set
main_dir = 'F:\Workspace\Rworkspace\Action_recognition_Still\Action';
subfold ={'Phoning','PlayingGuitar','RidingBike','RidingHorse','Running','Shooting'};
for cls_subfold = 1:6
    %disp(subfold)
    directory = fullfile(main_dir,'train',subfold{cls_subfold});
    dirs=dir([directory,'.\*.jpg']);%dirs�ṹ������,���������ļ������������ļ�������Ϣ��
    dircell=struct2cell(dirs)'; %����ת����ת��ΪԪ������
    filenames=dircell(:,1) ;%�ļ����ʹ���ڵ�һ��
    [n m] = size(filenames);%��ô�С
    rng(100);
    n_smp =randsample(n,floor(0.25*n));
    for i = 1:length(n_smp)        
     if ~isempty( strfind(filenames{n_smp(i)}, '.jpg') )%ɸѡ��tif�ļ�
         filename = filenames{n_smp(i)};
         filepath = fullfile(directory,filename);
         movefile(filepath,fullfile(main_dir,'val',subfold{cls_subfold}))
     end
    end
    disp(['The assignment for ',subfold{cls_subfold},' has been completed!']);
    
end

